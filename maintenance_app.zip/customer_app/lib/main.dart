import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:geolocator/geolocator.dart';
import 'package:intl/intl.dart';

// هذا الملف يُولَّد تلقائيًا عند تنفيذ: flutterfire configure
import 'firebase_options.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  runApp(const CustomerApp());
}

class CustomerApp extends StatelessWidget {
  const CustomerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'طلب صيانة',
      debugShowCheckedModeBanner: false,
      locale: const Locale('ar'),
      theme: ThemeData(
        colorSchemeSeed: const Color(0xFF0F6D4F),
        useMaterial3: true,
        fontFamily: 'Cairo',
      ),
      home: const RequestFormPage(),
    );
  }
}

class RequestFormPage extends StatefulWidget {
  const RequestFormPage({super.key});

  @override
  State<RequestFormPage> createState() => _RequestFormPageState();
}

class _RequestFormPageState extends State<RequestFormPage> {
  final _formKey = GlobalKey<FormState>();
  final _nameCtrl = TextEditingController();
  final _phoneCtrl = TextEditingController();
  final _descCtrl = TextEditingController();

  final List<String> _faultTypes = ['ثلاجة', 'غسالة', 'مكيف', 'سخان', 'أخرى'];
  String _selectedFault = 'ثلاجة';

  Position? _position;
  bool _locating = false;
  bool _submitting = false;

  @override
  void initState() {
    super.initState();
    _getLocation();
  }

  Future<void> _getLocation() async {
    setState(() => _locating = true);
    try {
      bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) {
        _showMessage('يرجى تفعيل خدمة الموقع (GPS) في جهازك');
        setState(() => _locating = false);
        return;
      }

      LocationPermission permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
        if (permission == LocationPermission.denied) {
          _showMessage('تم رفض إذن الموقع، لا يمكن تحديد موقعك');
          setState(() => _locating = false);
          return;
        }
      }
      if (permission == LocationPermission.deniedForever) {
        _showMessage('إذن الموقع مرفوض بشكل دائم، فعّله من إعدادات الجهاز');
        setState(() => _locating = false);
        return;
      }

      final pos = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
      );
      setState(() {
        _position = pos;
        _locating = false;
      });
    } catch (e) {
      _showMessage('تعذر تحديد الموقع: $e');
      setState(() => _locating = false);
    }
  }

  void _showMessage(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    if (_position == null) {
      _showMessage('لم يتم تحديد موقعك بعد، حاول مرة أخرى');
      return;
    }

    setState(() => _submitting = true);
    try {
      await FirebaseFirestore.instance.collection('requests').add({
        'customerName': _nameCtrl.text.trim(),
        'phone': _phoneCtrl.text.trim(),
        'faultType': _selectedFault,
        'description': _descCtrl.text.trim(),
        'latitude': _position!.latitude,
        'longitude': _position!.longitude,
        'status': 'pending',
        'createdAt': FieldValue.serverTimestamp(),
      });
      if (!mounted) return;
      _showMessage('تم إرسال طلبك بنجاح، سيتم التواصل معك قريبًا');
      _nameCtrl.clear();
      _phoneCtrl.clear();
      _descCtrl.clear();
      setState(() => _selectedFault = _faultTypes.first);
    } catch (e) {
      _showMessage('حدث خطأ أثناء إرسال الطلب: $e');
    } finally {
      if (mounted) setState(() => _submitting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('طلب صيانة جهاز كهربائي')),
        body: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                TextFormField(
                  controller: _nameCtrl,
                  decoration: const InputDecoration(
                    labelText: 'الاسم الكامل',
                    border: OutlineInputBorder(),
                  ),
                  validator: (v) => (v == null || v.trim().isEmpty) ? 'مطلوب' : null,
                ),
                const SizedBox(height: 12),
                TextFormField(
                  controller: _phoneCtrl,
                  keyboardType: TextInputType.phone,
                  decoration: const InputDecoration(
                    labelText: 'رقم الهاتف',
                    border: OutlineInputBorder(),
                  ),
                  validator: (v) => (v == null || v.trim().isEmpty) ? 'مطلوب' : null,
                ),
                const SizedBox(height: 12),
                DropdownButtonFormField<String>(
                  value: _selectedFault,
                  decoration: const InputDecoration(
                    labelText: 'نوع العطل / الجهاز',
                    border: OutlineInputBorder(),
                  ),
                  items: _faultTypes
                      .map((f) => DropdownMenuItem(value: f, child: Text(f)))
                      .toList(),
                  onChanged: (v) => setState(() => _selectedFault = v!),
                ),
                const SizedBox(height: 12),
                TextFormField(
                  controller: _descCtrl,
                  maxLines: 3,
                  decoration: const InputDecoration(
                    labelText: 'وصف إضافي للعطل (اختياري)',
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 16),
                Card(
                  child: ListTile(
                    leading: _locating
                        ? const SizedBox(
                            width: 24,
                            height: 24,
                            child: CircularProgressIndicator(strokeWidth: 2))
                        : Icon(
                            _position != null ? Icons.location_on : Icons.location_off,
                            color: _position != null ? Colors.green : Colors.red,
                          ),
                    title: Text(_position != null
                        ? 'تم تحديد الموقع: ${_position!.latitude.toStringAsFixed(5)}, ${_position!.longitude.toStringAsFixed(5)}'
                        : (_locating ? 'جارٍ تحديد موقعك...' : 'لم يتم تحديد الموقع')),
                    trailing: IconButton(
                      icon: const Icon(Icons.refresh),
                      onPressed: _locating ? null : _getLocation,
                    ),
                  ),
                ),
                const SizedBox(height: 20),
                FilledButton(
                  onPressed: _submitting ? null : _submit,
                  style: FilledButton.styleFrom(padding: const EdgeInsets.all(16)),
                  child: _submitting
                      ? const SizedBox(
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                      : const Text('إرسال الطلب'),
                ),
                const SizedBox(height: 24),
                const Divider(),
                const Padding(
                  padding: EdgeInsets.symmetric(vertical: 8),
                  child: Text('طلباتي السابقة', style: TextStyle(fontWeight: FontWeight.bold)),
                ),
                _MyRequestsList(phone: _phoneCtrl.text),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _MyRequestsList extends StatelessWidget {
  final String phone;
  const _MyRequestsList({required this.phone});

  String _statusLabel(String status) {
    switch (status) {
      case 'accepted':
        return 'تم القبول';
      case 'completed':
        return 'مكتمل';
      case 'rejected':
        return 'مرفوض';
      default:
        return 'قيد الانتظار';
    }
  }

  @override
  Widget build(BuildContext context) {
    if (phone.trim().isEmpty) {
      return const Padding(
        padding: EdgeInsets.all(8),
        child: Text('اكتب رقم هاتفك أعلاه لعرض طلباتك السابقة'),
      );
    }
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance
          .collection('requests')
          .where('phone', isEqualTo: phone.trim())
          .orderBy('createdAt', descending: true)
          .limit(10)
          .snapshots(),
      builder: (context, snapshot) {
        if (!snapshot.hasData) {
          return const Padding(
            padding: EdgeInsets.all(8),
            child: LinearProgressIndicator(),
          );
        }
        final docs = snapshot.data!.docs;
        if (docs.isEmpty) {
          return const Padding(
            padding: EdgeInsets.all(8),
            child: Text('لا توجد طلبات سابقة بهذا الرقم'),
          );
        }
        return Column(
          children: docs.map((d) {
            final data = d.data() as Map<String, dynamic>;
            final ts = data['createdAt'] as Timestamp?;
            final dateStr = ts != null
                ? DateFormat('yyyy-MM-dd HH:mm').format(ts.toDate())
                : '--';
            return Card(
              child: ListTile(
                title: Text(data['faultType'] ?? ''),
                subtitle: Text(dateStr),
                trailing: Chip(label: Text(_statusLabel(data['status'] ?? 'pending'))),
              ),
            );
          }).toList(),
        );
      },
    );
  }
}
