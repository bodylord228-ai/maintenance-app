import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:intl/intl.dart';

// هذا الملف يُولَّد تلقائيًا عند تنفيذ: flutterfire configure
import 'firebase_options.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  runApp(const ProviderApp());
}

class ProviderApp extends StatelessWidget {
  const ProviderApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'طلبات الصيانة',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(colorSchemeSeed: const Color(0xFF0F4D8D), useMaterial3: true),
      home: const RequestsListPage(),
    );
  }
}

class RequestsListPage extends StatefulWidget {
  const RequestsListPage({super.key});

  @override
  State<RequestsListPage> createState() => _RequestsListPageState();
}

class _RequestsListPageState extends State<RequestsListPage> {
  String _filter = 'pending';

  final Map<String, String> _statusLabels = {
    'pending': 'قيد الانتظار',
    'accepted': 'مقبولة',
    'completed': 'مكتملة',
    'rejected': 'مرفوضة',
  };

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('طلبات الصيانة الواردة')),
        body: Column(
          children: [
            SizedBox(
              height: 52,
              child: ListView(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
                children: _statusLabels.entries.map((e) {
                  final selected = _filter == e.key;
                  return Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 4),
                    child: ChoiceChip(
                      label: Text(e.value),
                      selected: selected,
                      onSelected: (_) => setState(() => _filter = e.key),
                    ),
                  );
                }).toList(),
              ),
            ),
            Expanded(
              child: StreamBuilder<QuerySnapshot>(
                stream: FirebaseFirestore.instance
                    .collection('requests')
                    .where('status', isEqualTo: _filter)
                    .orderBy('createdAt', descending: true)
                    .snapshots(),
                builder: (context, snapshot) {
                  if (snapshot.hasError) {
                    return Center(child: Text('خطأ: ${snapshot.error}'));
                  }
                  if (!snapshot.hasData) {
                    return const Center(child: CircularProgressIndicator());
                  }
                  final docs = snapshot.data!.docs;
                  if (docs.isEmpty) {
                    return const Center(child: Text('لا توجد طلبات في هذه الحالة'));
                  }
                  return ListView.builder(
                    padding: const EdgeInsets.all(8),
                    itemCount: docs.length,
                    itemBuilder: (context, i) {
                      final doc = docs[i];
                      final data = doc.data() as Map<String, dynamic>;
                      return _RequestCard(docId: doc.id, data: data);
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _RequestCard extends StatelessWidget {
  final String docId;
  final Map<String, dynamic> data;
  const _RequestCard({required this.docId, required this.data});

  Future<void> _updateStatus(String newStatus) {
    return FirebaseFirestore.instance
        .collection('requests')
        .doc(docId)
        .update({'status': newStatus});
  }

  Future<void> _openMap(double lat, double lng) async {
    final uri = Uri.parse('https://maps.google.com/?q=$lat,$lng');
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    }
  }

  Future<void> _call(String phone) async {
    final uri = Uri.parse('tel:$phone');
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri);
    }
  }

  @override
  Widget build(BuildContext context) {
    final status = data['status'] ?? 'pending';
    final ts = data['createdAt'] as Timestamp?;
    final dateStr = ts != null ? DateFormat('yyyy-MM-dd HH:mm').format(ts.toDate()) : '--';
    final lat = (data['latitude'] as num?)?.toDouble();
    final lng = (data['longitude'] as num?)?.toDouble();

    return Card(
      margin: const EdgeInsets.symmetric(vertical: 6),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(data['faultType'] ?? '', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                Text(dateStr, style: const TextStyle(color: Colors.grey, fontSize: 12)),
              ],
            ),
            const SizedBox(height: 6),
            Text('العميل: ${data['customerName'] ?? ''}'),
            Row(
              children: [
                Text('الهاتف: ${data['phone'] ?? ''}'),
                IconButton(
                  icon: const Icon(Icons.call, size: 18),
                  onPressed: () => _call(data['phone'] ?? ''),
                ),
              ],
            ),
            if ((data['description'] ?? '').toString().isNotEmpty)
              Padding(
                padding: const EdgeInsets.only(top: 4),
                child: Text('وصف: ${data['description']}'),
              ),
            if (lat != null && lng != null)
              Padding(
                padding: const EdgeInsets.only(top: 6),
                child: OutlinedButton.icon(
                  onPressed: () => _openMap(lat, lng),
                  icon: const Icon(Icons.location_on),
                  label: const Text('فتح الموقع على الخريطة'),
                ),
              ),
            const SizedBox(height: 10),
            Wrap(
              spacing: 8,
              children: [
                if (status == 'pending') ...[
                  FilledButton(
                    onPressed: () => _updateStatus('accepted'),
                    child: const Text('قبول'),
                  ),
                  OutlinedButton(
                    onPressed: () => _updateStatus('rejected'),
                    child: const Text('رفض'),
                  ),
                ],
                if (status == 'accepted')
                  FilledButton(
                    onPressed: () => _updateStatus('completed'),
                    child: const Text('تم الإنجاز'),
                  ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
